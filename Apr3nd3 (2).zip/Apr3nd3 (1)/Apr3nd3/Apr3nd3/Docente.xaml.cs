﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Apr3nd3 {
	/// <summary>
	/// Lógica de interacción para Docente.xaml
	/// </summary>
	public partial class Docente : Window {
		public Docente() {
			InitializeComponent();
		}

        private void Registro_Click(object sender, RoutedEventArgs e)
        {
            bool res;
            SqlConnection con;
            SqlCommand cmd;

            con = Conexion.agregarConexion();
            cmd = new SqlCommand(String.Format("insert into usuario " +
                "(nomUsuario,pila,paterno,materno,tipo,contra,grado) " +
                "values ('{0}','{1}','{2}','{3}','{4}','{5}', {6})",
                TbUsuario.Text, TbNomPila.Text, TbApellPaterno.Text, TbApellMaterno.Text, "Maestro",
                TbContra.Text, Int16.Parse(TbNivel.Text)), con);
            res = cmd.ExecuteNonQuery() >0;

            cmd = new SqlCommand(String.Format("insert into maestro values ('{0}', year(getDate()),'{1}')",
                TbUsuario.Text,TbTitulo1.Text), con);
            res &= cmd.ExecuteNonQuery() > 0;

            if (TbEsp1.Text != null)
            {
                cmd = new SqlCommand(String.Format("insert into especialidad values('{0}','{1}')",
                    TbUsuario.Text, TbEsp1.Text), con);
                res &= cmd.ExecuteNonQuery() > 0;
            }

            if (TbEsp2.Text != null)
            {
                cmd = new SqlCommand(String.Format("insert into especialidad values('{0}','{1}')",
                    TbUsuario.Text, TbEsp2.Text), con);
                res &= cmd.ExecuteNonQuery() > 0;
            }

            if (TbEsp3.Text != null)
            {
                cmd = new SqlCommand(String.Format("insert into especialidad values('{0}','{1}')",
                    TbUsuario.Text, TbEsp3.Text), con);
                res &= cmd.ExecuteNonQuery () >0;
            }

            if (res)
                MessageBox.Show("Alta exitosa");
            else
                MessageBox.Show("Alta fallida");
            con.Close();


            Iniciar w = new Iniciar();
			this.Hide();
			w.Show();

		}

        private void TbUsuario_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
