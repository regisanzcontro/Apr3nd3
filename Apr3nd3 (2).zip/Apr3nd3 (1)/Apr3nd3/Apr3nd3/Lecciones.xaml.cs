﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Apr3nd3
{
    /// <summary>
    /// Lógica de interacción para Lecciones.xaml
    /// </summary>
    public partial class Lecciones : Window
    {
        String claveMat; 
        public Lecciones()
        {
            InitializeComponent();
        }

        public Lecciones(String claveMat)
        {
            InitializeComponent();
            this.claveMat = claveMat; 
        }
        private void cbLecciones_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //el elemento elegido poner el contenido en el textblock 
            // 
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            SqlConnection miConexion = Conexion.agregarConexion();
            SqlCommand cmd = new SqlCommand(String.Format("select lecciones.idLeccion from lecciones inner join materia on materia.idMat = lecciones.idMat where idMat = {0}",claveMat),miConexion);//no sabemos si esta bien 
            SqlDataReader rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                cbLecciones.Items.Add(rd["lecciones.idLeccion"].ToString());
            }
            rd.Close();
        }

        private void BtSubir_Click(object sender, RoutedEventArgs e)
        {
            //guardar la info del textblock en la tabla de leccion-alumno
        }
    }
}
