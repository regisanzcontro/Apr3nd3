﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Apr3nd3
{
    /// <summary>
    /// Lógica de interacción para Estudiante.xaml
    /// </summary>
    public partial class Estudiante : Window
    {
        public Estudiante()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            
            int res;
            SqlConnection con;
            SqlCommand cmd, cmd2;

            con = Conexion.agregarConexion();
            cmd = new SqlCommand(String.Format("insert into usuario " +
                "(nomUsuario,pila,paterno,materno,tipo,contra,grado) " +
                "values ('{0}','{1}','{2}','{3}','{4}','{5}',{6})",
                TbNomUsuario.Text, TbNombre.Text, TbApellPaterno.Text, TbApellMaterno.Text, "Estudiante",
                TbContraseña.Text, Int16.Parse(TbAño.Text)),con);
            res = cmd.ExecuteNonQuery();

            cmd2 = new SqlCommand(String.Format("insert into estudiante values ('{0}',{1})",
                TbNomUsuario.Text, Int16.Parse(TbFecNac.Text)), con);
            cmd2.ExecuteNonQuery();

            if (res>0)
                MessageBox.Show("Alta exitosa");
            else
                MessageBox.Show("Alta fallida");
            con.Close();  

            IniciarEst w = new IniciarEst();
            this.Hide();
            w.Show();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void TbContraseña_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
