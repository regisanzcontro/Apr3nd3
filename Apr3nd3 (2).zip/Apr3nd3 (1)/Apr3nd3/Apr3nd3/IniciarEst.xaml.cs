﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Apr3nd3
{
    /// <summary>
    /// Lógica de interacción para IniciarEst.xaml
    /// </summary>
    public partial class IniciarEst : Window
    {
        public IniciarEst()
        {
            InitializeComponent();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            SqlConnection con = Conexion.agregarConexion();
            SqlCommand cmd = new SqlCommand("select nomUsuario from usuario where" +
                " (usuario.nomUsuario = '"+TbUsuario.Text+"') and (usuario.contra = '" + TbContraseña.Text+ "')", con);
            SqlDataReader dr = cmd.ExecuteReader();
            if(dr.Read())
            {
                MessageBox.Show("Usuario encontrado");
                String nomU = dr.GetString(0);
                con.Close();
                this.Close();
                MenuEstud w = new MenuEstud(nomU);
                w.Show();
            }
            else
            {
                MessageBox.Show("Usuario no encontrado");
                con.Close();
            }
            
            
            
        }
    }
}
