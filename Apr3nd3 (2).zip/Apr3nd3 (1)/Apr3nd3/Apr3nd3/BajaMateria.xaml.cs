﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Apr3nd3
{
    /// <summary>
    /// Lógica de interacción para BajaMateria.xaml
    /// </summary>
    public partial class BajaMateria : Window
    {
        String nomUsuario;
        public BajaMateria(string nomUsuario)
        {
            InitializeComponent();
            this.nomUsuario = nomUsuario;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            bool res;
            SqlConnection con;
            SqlCommand cmd;

            con = Conexion.agregarConexion();
            cmd = new SqlCommand("delete from usuarioMateria " +
                "where nomUsuario = '"+nomUsuario+"' and idMat = "+ TbClaveMat.Text, con);
            res = cmd.ExecuteNonQuery() > 0;

            if (res)
                MessageBox.Show("Baja exitosa de materia");
            else
                MessageBox.Show("Baja de materia fallida");
            con.Close();
        }
    }
}
