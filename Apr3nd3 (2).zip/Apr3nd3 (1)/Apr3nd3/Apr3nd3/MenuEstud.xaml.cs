﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Apr3nd3
{
    /// <summary>
    /// Lógica de interacción para MenuEstud.xaml
    /// </summary>
    public partial class MenuEstud : Window
    {
        String nomUsuario;
        public MenuEstud(string nomUsuario)
        {
            InitializeComponent();
            this.nomUsuario = nomUsuario;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            AltaMateria w = new AltaMateria(nomUsuario);
            this.Hide();
            w.Show();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            BajaMateria w = new BajaMateria(nomUsuario);
            this.Hide();
            w.Show(); 
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            BuscarMateria w = new BuscarMateria(nomUsuario);
            this.Hide();
            w.Show();
        }
    }
}
