﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Apr3nd3
{
    /// <summary>
    /// Lógica de interacción para BuscarMateria.xaml
    /// </summary>
    public partial class BuscarMateria : Window
    {
        String nomUsuario;
        public BuscarMateria(string nomUsuario)
        {
            InitializeComponent();
            this.nomUsuario = nomUsuario;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            bool res;
            SqlConnection con;
            SqlCommand cmd;
            String claveMat = TbClaveMateria.Text;

            con = Conexion.agregarConexion();
            cmd = new SqlCommand (String.Format("select idMat from materia where idMat='{0}'", claveMat),con);
            res = cmd.ExecuteNonQuery() > 0;
            if (res)
            {
                MessageBox.Show("SI encontró la materia");
                Lecciones w = new Lecciones(claveMat);
                this.Hide();
                w.Show();
            }    
            else
                MessageBox.Show("No existe");
            con.Close(); 
        }

    }
}
